const HTTP_RESPONSE = Object.freeze({
  OK: 200,
  NOT_FOUND: 404,
});

export default HTTP_RESPONSE;

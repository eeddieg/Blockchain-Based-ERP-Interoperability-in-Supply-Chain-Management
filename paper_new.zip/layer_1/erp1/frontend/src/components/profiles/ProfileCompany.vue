<template>
  <div class="dashboard">
    <div v-if="user.role === adminRole">
      <h1>
        Welcome {{ user.firstName }}
        <span class="badge badge-pill bg-success">{{ user.role }}</span>
      </h1>
    </div>
    <br />
    <section>
      <div class="container">
        <div class="main-body">
          <div class="row">
            <div class="col-lg-4">
              <div class="card">
                <div class="card-body">
                  <div
                    class="d-flex flex-column align-items-center text-center"
                  >
                    <img
                      :src="profilePic"
                      :alt="`${user.role}`"
                      class="rounded-circle p-1 bg-primary"
                      width="110"
                    />
                    <div class="mt-3">
                      <h4>{{ user.firstName }} {{ user.lastName }}</h4>
                      <p class="text-secondary mb-1">{{ user.role }}</p>
                      <p class="text-muted font-size-sm">
                        Bay Area, San Francisco, CA
                      </p>
                    </div>
                  </div>
                  <hr class="my-4" />
                  <ul class="list-group list-group-flush">
                    <li
                      class="list-group-item d-flex justify-content-between align-items-center flex-wrap"
                    >
                      <h6 class="mb-0">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          class="feather feather-github me-2 icon-inline"
                        >
                          <path
                            d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"
                          ></path>
                        </svg>
                        Github
                      </h6>
                      <span class="text-secondary">bootdey</span>
                    </li>
                    <li
                      class="list-group-item d-flex justify-content-between align-items-center flex-wrap"
                    >
                      <h6 class="mb-0">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          class="feather feather-twitter me-2 icon-inline text-info"
                        >
                          <path
                            d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"
                          ></path>
                        </svg>
                        Twitter
                      </h6>
                      <span class="text-secondary">@bootdey</span>
                    </li>
                    <li
                      class="list-group-item d-flex justify-content-between align-items-center flex-wrap"
                    >
                      <h6 class="mb-0">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          class="feather feather-instagram me-2 icon-inline text-danger"
                        >
                          <rect
                            x="2"
                            y="2"
                            width="20"
                            height="20"
                            rx="5"
                            ry="5"
                          ></rect>
                          <path
                            d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"
                          ></path>
                          <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                        </svg>
                        Instagram
                      </h6>
                      <span class="text-secondary">bootdey</span>
                    </li>
                    <li
                      class="list-group-item d-flex justify-content-between align-items-center flex-wrap"
                    >
                      <h6 class="mb-0">
                        <svg
                          xmlns="http://www.w3.org/2000/svg"
                          width="24"
                          height="24"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          class="feather feather-facebook me-2 icon-inline text-primary"
                        >
                          <path
                            d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"
                          ></path>
                        </svg>
                        Facebook
                      </h6>
                      <span class="text-secondary">bootdey</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-lg-8">
              <div class="card">
                <div class="card-body">
                  <h4 class="d-flex align-items-center mb-4">Company Info</h4>
                  <form class="g-3 needs-validation" novalidate>
                    <div class="row mb-3">
                      <label for="inputName" class="form-label col-sm-4">
                        Company Name (Brand)
                      </label>
                      <div class="col-sm-8">
                        <input
                          id="inputName"
                          type="text"
                          class="form-control"
                          :value="`${company?.name}`"
                          required
                        />
                        <div class="valid-feedback">Looks good!</div>
                      </div>
                    </div>
                    <div class="row mb-3">
                      <label for="inputEmail" class="form-label col-sm-4">
                        Email
                      </label>
                      <div class="col-sm-8">
                        <input
                          id="inputEmail"
                          type="email"
                          class="form-control"
                          :value="`${company?.email}`"
                          required
                        />
                        <div class="valid-feedback">Looks good!</div>
                      </div>
                    </div>
                    <div class="row mb-3">
                      <label for="inputPhone" class="form-label col-sm-4">
                        Phone
                      </label>
                      <div class="col-sm-8">
                        <input
                          id="inputPhone"
                          type="text"
                          class="form-control"
                          :value="`${company?.phone}`"
                        />
                        <div class="valid-feedback">Looks good!</div>
                      </div>
                    </div>
                    <div class="row mb-3">
                      <label for="inputMobile" class="form-label col-sm-4">
                        Mobile
                      </label>
                      <div class="col-sm-8">
                        <input
                          id="inputMobile"
                          type="text"
                          class="form-control"
                          :value="`${company?.mobile}`"
                        />
                        <div class="valid-feedback">Looks good!</div>
                      </div>
                    </div>
                    <div class="row mb-3">
                      <label for="inputAddress" class="form-label col-sm-4">
                        Address
                      </label>
                      <div class="col-sm-8">
                        <input
                          id="inputAddress"
                          type="text"
                          class="form-control"
                          :value="`${company?.address}`"
                        />
                        <div class="valid-feedback">Looks good!</div>
                      </div>
                    </div>
                    <div class="row mb-3">
                      <label for="inputReserved" class="form-label col-sm-4">
                        Reserved Resources
                      </label>
                      <div class="col-sm-8">
                        <input
                          id="inputReserved"
                          type="number"
                          class="form-control text-danger"
                          :value="`${company?.reservedResources}`"
                        />
                        <div class="valid-feedback">Looks good!</div>
                      </div>
                    </div>
                    <div class="row mb-3">
                      <label for="inputAvailable" class="form-label col-sm-4">
                        Available Resources
                      </label>
                      <div class="col-sm-8">
                        <input
                          id="inputAvailable"
                          type="number"
                          class="form-control text-success"
                          :value="`${company?.availableResources}`"
                        />
                        <div class="valid-feedback">Looks good!</div>
                      </div>
                    </div>
                    <div class="row md-3">
                      <label for="productToBuy" class="form-label col-sm-4">
                        Product Inbound
                      </label>
                      <div class="col-sm-8">
                        <select
                          id="productToBuy"
                          class="form-select"
                          v-model="company.productToBuy"
                          @change="setBuyValue"
                          required
                        >
                          <option selected disabled value="">
                            Select the product company buys
                          </option>
                          <option :value="`${WHEAT_SEED}`">WHEAT SEED</option>
                          <option :value="`${WHEAT}`">WHEAT</option>
                          <option :value="`${WHEAT_SACK}`">WHEAT SACK</option>
                          <option :value="`${WHEAT_SACK_PALLETE_PRE}`">
                            WHEAT SACK PALLETE (PRE)
                          </option>
                          <option :value="`${WHEAT_SACK_PALLETE_POST}`">
                            WHEAT SACK PALLETE (POST)
                          </option>
                          <option :value="`${FLOUR}`">FLOUR</option>
                          <option :value="`${BREAD_PRODUCT}`">
                            BREAD PRODUCT (FACTORY)
                          </option>
                          <option :value="`${DISTRIBUTED_BREAD_PRODUCT}`">
                            BREAD PRODUCT (DISTRIBUTED)
                          </option>
                          <option :value="`${BREAD_PRODUCT_CONSUMER}`">
                            BREAD PRODUCT (CONSUMER)
                          </option>
                        </select>
                        <div class="valid-feedback">Looks good!</div>
                        <div class="invalid-feedback">
                          Please select a valid state.
                        </div>
                      </div>
                    </div>
                    <div class="row my-3">
                      <label for="productToSell" class="form-label col-sm-4">
                        Product Outbound
                      </label>
                      <div class="col-sm-8">
                        <select
                          id="productToSell"
                          class="form-select"
                          v-model="company.productToSell"
                          @change="setSellValue"
                          required
                        >
                          <option selected disabled value="">
                            Select the product company sells
                          </option>
                          <option :value="`${WHEAT_SEED}`">WHEAT SEED</option>
                          <option :value="`${WHEAT}`">WHEAT</option>
                          <option :value="`${WHEAT_SACK}`">WHEAT SACK</option>
                          <option :value="`${WHEAT_SACK_PALLETE_PRE}`">
                            WHEAT SACK PALLETE (PRE)
                          </option>
                          <option :value="`${WHEAT_SACK_PALLETE_POST}`">
                            WHEAT SACK PALLETE (POST)
                          </option>
                          <option :value="`${FLOUR}`">FLOUR</option>
                          <option :value="`${BREAD_PRODUCT}`">
                            BREAD PRODUCT (FACTORY)
                          </option>
                          <option :value="`${DISTRIBUTED_BREAD_PRODUCT}`">
                            BREAD PRODUCT (DISTRIBUTED)
                          </option>
                          <option :value="`${BREAD_PRODUCT_CONSUMER}`">
                            BREAD PRODUCT (CONSUMER)
                          </option>
                        </select>
                        <div class="valid-feedback">Looks good!</div>
                        <div class="invalid-feedback">
                          Please select a valid state.
                        </div>
                      </div>
                    </div>
                    <div class="col-12">
                      <button
                        class="btn btn-primary"
                        type="submit"
                        @submit="submitChanges"
                      >
                        Save
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script lang="ts">
import { ref } from "vue";
import { useStore } from "vuex";
import { Company } from "../../models/company.model";
import { ProductBc } from "../../models/order.model";
import { User, UserRole } from "../../models/user.model";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let store: any;
let user: User;

const WHEAT_SEED = ProductBc.WHEAT_SEED;
const WHEAT = ProductBc.WHEAT;
const WHEAT_SACK = ProductBc.WHEAT_SACK;
const WHEAT_SACK_PALLETE_PRE = ProductBc.WHEAT_SACK_PALLETE_PRE;
const WHEAT_SACK_PALLETE_POST = ProductBc.WHEAT_SACK_PALLETE_POST;
const FLOUR = ProductBc.FLOUR;
const BREAD_PRODUCT = ProductBc.BREAD_PRODUCT;
const DISTRIBUTED_BREAD_PRODUCT = ProductBc.DISTRIBUTED_BREAD_PRODUCT;
const BREAD_PRODUCT_CONSUMER = ProductBc.BREAD_PRODUCT_CONSUMER;

export default {
  name: "CompanyProfileComponent",
  data() {
    // const comp = store.getters.getCompany as Company;
    return {
      adminRole: UserRole.ADMIN,
      company: store.getters.getCompany as Company,
      modRole: UserRole.MODERATOR,
      userRole: UserRole.USER,
    };
  },
  mounted() {
    store.dispatch("fetchCompanyResourcesFromBc").then((res: Company) => {
      if (res.name === this.company.name) {
        this.company.reservedResources = res.reservedResources;
        this.company.availableResources = res.availableResources;
      }
    });
    this.checkValidation();
  },
  setup() {
    store = useStore();
    user = ref(store.getters.user).value;
    let profilePic = "";

    return {
      WHEAT_SEED,
      WHEAT,
      WHEAT_SACK,
      WHEAT_SACK_PALLETE_PRE,
      WHEAT_SACK_PALLETE_POST,
      FLOUR,
      BREAD_PRODUCT,
      DISTRIBUTED_BREAD_PRODUCT,
      BREAD_PRODUCT_CONSUMER,
      profilePic,
      user,
    };
  },
  methods: {
    checkValidation() {
      const forms = document.querySelectorAll(".needs-validation");

      Array.prototype.slice.call(forms).forEach((form) => {
        form.addEventListener(
          "submit",
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          (event: any) => {
            if (!form.checkValidity()) {
              event.preventDefault();
              event.stopPropagation();
            }
            form.classList.add("was-validated");
          },
          false
        );
      });
    },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    setSellValue(event: any) {
      this.company.productToSell = event.target.value as ProductBc;
    },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    setBuyValue(event: any) {
      this.company.productToBuy = event.target.value as ProductBc;
    },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    async submitChanges(event: any) {
      console.log(event);
      event.preventDefault();
      const toBuy = this.company.productToBuy;
      const toSell = this.company.productToSell;
      if (toBuy === "" || toSell === "") {
        return;
      }

      await store.commit("setCompanyDetails", this.company);
      const res = await store.dispatch("updateCompanyInfoOnBc", this.company);
      console.log(res);
    },
  },
};
</script>

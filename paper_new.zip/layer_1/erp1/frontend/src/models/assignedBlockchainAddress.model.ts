export type AssignedBlockchainAddress = {
  id: number;
  userId: number;
  address: string;
};

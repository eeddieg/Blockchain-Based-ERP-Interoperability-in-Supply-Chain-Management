export type AvailableBlockchainAddress = {
  id: number;
  address: string;
};

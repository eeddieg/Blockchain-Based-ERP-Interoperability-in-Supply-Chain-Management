# apiServer

## Built using Express, Typescript and Prisma ORM

Run:
npm i && npx prisma db push && npx prisma db seed
npm run dev

## DOCKER

docker build -t erp/company_a/backend .

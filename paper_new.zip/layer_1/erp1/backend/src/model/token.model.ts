export type TraceabilityToken = {
  id?:        number;
  orderId:    number;
  bcTokenId:  number;
  token:      string;
}
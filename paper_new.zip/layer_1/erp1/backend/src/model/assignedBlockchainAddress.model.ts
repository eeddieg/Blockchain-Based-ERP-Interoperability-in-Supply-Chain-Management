export type AssignedBlockchainAddress = {
  id?:      number,
  address:  string,
  email:    string,
}
